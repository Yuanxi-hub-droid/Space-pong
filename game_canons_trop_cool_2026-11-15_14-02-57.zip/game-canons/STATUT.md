﻿# Statut de Game Canons

État constaté le 14 novembre 2026 à partir des fichiers du projet. Le projet est un prototype : les comportements ci-dessous sont déduits des scènes et du code, sans test de lancement pendant cet état des lieux.

## Déjà fait

- Le concept et les règles sont décrits dans `specifications-jeu.md`.
- Le projet Godot « game canons » possède une scène principale et une scène de robot placée au centre.
- Le robot et son bouclier sont dessinés avec des formes simples. Le script place le bouclier en haut au démarrage et le déplace sur les quatre côtés avec les flèches.
- Sept visuels SVG ont été préparés dans `visuels_canons` : cinq couleurs de boulets et deux états de canon. Ils ne sont pas encore utilisés dans les scènes du jeu.
- `GUIDE_DEBUTANT.md` décrit les prochaines étapes de réalisation et de test.
- Cette copie rassemble le projet, les visuels et les documents ; le projet original se trouve dans `OneDrive/Documents/game-2.0`.

## Reste à faire

- [ ] Ouvrir cette copie dans Godot et vérifier le robot et les quatre directions du bouclier.
- [ ] Importer les visuels dans le projet et créer les scènes des canons et des boulets.
- [ ] Placer et orienter quatre canons autour du robot ; programmer leurs tirs et le déplacement des boulets.
- [ ] Ajouter les collisions, le blocage et le renvoi jaune vers le canon d'origine, avec les dégâts liés à la couleur initiale.
- [ ] Ajouter les points de vie du robot et des canons, leurs barres et l'apparence des canons détruits.
- [ ] Programmer les couleurs, vitesses et fréquences des tirs, les contraintes de synchronisation et la progression des niveaux décrites dans les spécifications.
- [ ] Ajouter la transition de niveau, la restauration des points de vie et des canons, puis la difficulté plafonnée au niveau 10.
- [ ] Créer l'écran de fin, le redémarrage au clic et la sauvegarde du meilleur niveau.
- [ ] Ajouter l'affichage du niveau et finaliser l'arène et la présentation.
- [ ] Tester les collisions et les quatre directions, équilibrer les paramètres et vérifier le jeu complet.
- [ ] Mettre le projet sur GitHub lorsque l'accès au compte et le dépôt de destination seront disponibles.

Les règles détaillées et les valeurs prévues figurent dans `specifications-jeu.md` ; le guide propose un ordre de travail. Les deux dossiers sont des copies indépendantes : les changements faits dans l'un ne se reportent pas automatiquement dans l'autre.
