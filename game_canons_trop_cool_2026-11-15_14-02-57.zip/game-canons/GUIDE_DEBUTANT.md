# Guide débutant : terminer le jeu du robot dans Godot 4.7

Ce guide accompagne le projet **game canons**. Le robot et le bouclier sont déjà créés. Les dessins des boulets et des canons ont été préparés dans le dossier `visuels_canons` à côté de ce guide ; ils ne sont pas encore dans le projet. Le jeu n'est pas encore terminé : suis les étapes dans l'ordre et demande de l'aide si une instruction ou une erreur te bloque.

Les vidéos expliquent les notions générales ; elles ne construisent pas exactement ce jeu. Les noms des boutons peuvent varier légèrement selon la langue ou la version de Godot.

## Avant de commencer

- Ouvre Godot et choisis le projet **game canons**.
- `Ctrl + S` enregistre la scène ou le script en cours. `F5` lance le projet ; `F6` lance la scène ouverte. Ferme la fenêtre du jeu pour revenir à l'éditeur.
- À gauche, l'arbre **Scène** contient les nœuds. En bas, **Système de fichiers** montre les fichiers. À droite, l'**Inspecteur** montre les propriétés du nœud sélectionné.
- Un **nœud** est un élément, une **scène** est un ensemble de nœuds, et un **script** donne des instructions à ces éléments.
- Après chaque étape, teste avant de continuer. S'il y a une erreur rouge, note son texte et le numéro de ligne ; tu peux me les envoyer.

Vidéo : [Les bases de Godot 4 en français](https://www.youtube.com/watch?v=cL5R3HioF8A), notamment la partie sur les scènes et nœuds. Autre ressource : [Votre premier jeu avec Godot 4](https://www.youtube.com/watch?v=Dj0joNnWKUI).

## 1. Vérifier le robot existant

1. Dans **Système de fichiers**, double-clique sur `main.tscn`.
2. Appuie sur `F6`. Le robot doit apparaître au centre ; appuie sur les quatre flèches. Le bouclier doit passer immédiatement d'un côté à l'autre.
3. Ferme la fenêtre du jeu. Double-clique sur `robot.tscn` pour voir les parties du robot. Ouvre `robot.gd` pour voir le script des flèches.
4. Si la scène ne fonctionne pas, demande de l'aide avant de continuer.

**À comprendre :** `main.tscn` utilise une instance de `robot.tscn`, c'est-à-dire une scène placée dans une autre scène.

## 2. Importer les images

1. Dans l'Explorateur Windows, ouvre le dossier `visuels_canons` fourni avec ce guide.
2. Sélectionne les sept fichiers `.svg` : les cinq boulets et les deux canons. Copie-les avec `Ctrl + C`.
3. Ouvre le dossier du projet `C:\Users\yuanx_vl2a472\OneDrive\Documents\game-2.0`.
4. Crée un dossier nommé `images`, ouvre-le et colle les fichiers avec `Ctrl + V`.
5. Retourne dans Godot et attends quelques secondes. Dans **Système de fichiers**, ouvre `res://images` et vérifie que les sept images apparaissent.

**Test :** double-clique sur une image pour vérifier que Godot la reconnaît. Les images sont des dessins ; elles ne tirent pas encore.

## 3. Créer un canon visible

1. Dans Godot, crée une nouvelle scène avec **Scène > Nouvelle scène**. Ajoute un nœud racine `Node2D` et renomme-le `Canon`.
2. Sélectionne `Canon`, clique sur **+ Ajouter un nœud enfant**, cherche `Sprite2D` et ajoute-le.
3. Sélectionne `Sprite2D`. Dans l'Inspecteur, trouve **Texture** et glisse `canon_normal.svg` depuis le panneau des fichiers dans cette propriété.
4. Enregistre la scène sous `canon.tscn` avec `Ctrl + S`.
5. Rouvre `main.tscn`. Glisse `canon.tscn` depuis le panneau des fichiers dans l'arbre de scène sous `Main`.
6. Sélectionne cette instance de canon et place-la vers le haut de l'arène, en face du robot. Les canons dessinés pointent initialement vers le haut : utilise la propriété **Rotation** de l'Inspecteur pour orienter leur ouverture vers le robot.
7. Enregistre `main.tscn` et lance avec `F6`.

**Test :** un canon et le robot apparaissent. Aucun tir n'est attendu pour l'instant.

## 4. Créer la scène d'un boulet

1. Crée une nouvelle scène dont le nœud racine est `Area2D`. Renomme-le `Boulet`.
2. Ajoute-lui deux enfants : un `Sprite2D` et un `CollisionShape2D`.
3. Sélectionne le `Sprite2D` et glisse `boulet_blanc.svg` dans sa propriété **Texture**.
4. Sélectionne `CollisionShape2D`. Dans l'Inspecteur, à côté de **Shape / Forme**, choisis **Nouveau CircleShape2D** ; clique sur la forme créée pour régler son rayon autour de l'image.
5. Enregistre la scène sous `boulet.tscn`. La zone de collision sert à détecter les contacts ; elle n'est pas visible dans le jeu normal.

Pour comprendre ces zones : [documentation officielle Area2D](https://docs.godotengine.org/fr/4.x/tutorials/physics/using_area_2d.html) et [exemple vidéo Godot 4 d'une zone de détection](https://www.youtube.com/watch?v=s92vdEEWpB8).

## 5. Faire avancer un boulet

1. Sélectionne la racine `Boulet`, clique sur **Attacher un script**, puis sur **Créer**.
2. Dans le script, définis une vitesse et une direction. Pour essayer, fais avancer le boulet vers le bas à chaque image :

```gdscript
extends Area2D

var vitesse: float = 180.0
var direction: Vector2 = Vector2.DOWN

func _process(delta: float) -> void:
	position += direction * vitesse * delta
```

3. Enregistre. Dans `main.tscn`, glisse temporairement `boulet.tscn` sous `Main`, place le boulet près du haut et lance la scène.
4. Vérifie qu'il descend, puis supprime cette instance temporaire dans `main.tscn` et enregistre. Le fichier `boulet.tscn` reste disponible.

**À comprendre :** `delta` est le temps écoulé depuis l'image précédente. Le multiplier par la vitesse rend le déplacement lié au temps plutôt qu'au nombre d'images affichées.

## 6. Faire tirer un canon

Cette étape demande plusieurs éléments de code ; nous pouvons l'écrire ensemble une fois l'étape 5 réussie.

1. Dans `canon.tscn`, ajoute un enfant `Marker2D` nommé `PointTir` au bout de l'ouverture : il indique le point de départ des boulets.
2. Ajoute un enfant `Timer` nommé `TimerTir` : il servira à compter le temps entre deux tirs.
3. Attache un script au nœud `Canon`. Charge la scène de boulet avec `preload("res://boulet.tscn")`.
4. Dans l'onglet **Nœud** à droite, connecte le signal `timeout` du `TimerTir` au script du canon. Lors du signal, crée une instance de boulet, ajoute-la à la scène principale, puis initialise sa position et sa direction vers le robot.
5. Au début, fais tirer un boulet blanc toutes les quelques secondes. Lance `main.tscn` et vérifie que les tirs partent du canon vers le robot.

Un **signal** est un message émis quand un événement arrive : ici, le minuteur annonce que son délai est écoulé. [Le parcours officiel Godot](https://docs.godotengine.org/fr/4.x/getting_started/step_by_step/) explique les signaux et les scripts.

## 7. Détecter les contacts et renvoyer les boulets

1. Ajoute une zone de détection `Area2D` et une `CollisionShape2D` au robot. Ajoute une autre zone avec une forme sous le bouclier. La zone du bouclier doit suivre ses quatre positions.
2. Configure les couches et masques de collision dans l'Inspecteur pour que le boulet puisse détecter le robot et le bouclier.
3. Connecte les signaux de contact `area_entered`. Si le bouclier est du bon côté, change l'image du boulet pour `boulet_jaune.svg` et sa direction vers son canon d'origine. Donne-lui la vitesse du boulet rouge du niveau.
4. Chaque boulet doit garder une référence à son canon d'origine et ses dégâts initiaux avant de changer de couleur.
5. Si un boulet non bloqué touche le robot, retire 1 HP et supprime le boulet. Si le boulet jaune atteint son canon, retire au canon les dégâts mémorisés et supprime le boulet.
6. Empêche un même boulet d'infliger plusieurs fois des dégâts ; teste les quatre directions et les légers angles.

**Test :** un boulet bloqué repart jaune vers le bon canon ; un boulet non bloqué enlève seulement 1 HP au robot. En cas de collisions inattendues, partage ton arbre de scène et tes scripts pour que nous les corrigions ensemble.

## 8. Barres de vie et destruction

1. Ajoute un `ProgressBar` dans l'interface pour les 5 HP du robot. Règle son maximum et sa valeur initiale à 5.
2. Ajoute une barre de vie à la scène `Canon`. Son maximum et sa valeur initiale correspondent aux HP du niveau.
3. Chaque fois que les HP changent, mets à jour la propriété `value` de la barre correspondante.
4. Quand un canon atteint 0 HP, arrête son minuteur et remplace sa texture par `canon_casse.svg`. Il reste affiché en sombre.
5. Vérifie que le robot ne perd jamais plus de 1 HP par boulet et que les canons arrêtés ne créent plus de tirs.

## 9. Quatre canons, couleurs et niveaux

1. Place quatre instances de canon dans `main.tscn`, une sur chaque côté, orientées vers le robot.
2. Ajoute au gestionnaire de partie les données de niveau : HP des canons, vitesses possibles, couleurs disponibles et plage des intervalles de tir.
3. Assigne au hasard un intervalle à chaque canon au début du niveau. Coordonne leurs tirs pour qu'ils ne partent pas au même instant. Au niveau 1, attends qu'il n'y ait plus de boulet à l'écran avant d'autoriser le prochain tir.
4. À partir du niveau 2, autorise plusieurs boulets à l'écran. Ajoute les vitesses et dégâts : blanc 1, vert 2, bleu 3, rouge 4 pour les canons. Le robot perd toujours 1 HP.
5. Applique la progression dans `specifications-jeu.md` : les HP vont de 3 au niveau 1 à 12 au niveau 10 ; les nouvelles couleurs apparaissent progressivement. À partir du niveau 10, les paramètres restent constants, mais les niveaux continuent.
6. Quand les quatre canons sont détruits, affiche « NIVEAU X » pendant une seconde, restaure les canons et les 5 HP du robot, puis reprends les tirs.

Les vitesses, intervalles et probabilités exacts restent à choisir pendant les essais. Nous les réglerons ensemble ; ne copie pas des valeurs d'une vidéo comme si elles étaient obligatoires.

## 10. Fin de partie et record

1. Ajoute une interface de fin cachée au départ : un `CanvasLayer`, avec des `Label` pour `YOU ARE DEAD`, le record et `Click to restart`.
2. Quand le robot atteint 0 HP, arrête les tirs et les interactions de jeu, affiche l'interface et calcule le meilleur niveau atteint.
3. Sauvegarde le record dans un fichier sous `user://`, puis recharge-le au démarrage. [Documentation officielle sur les chemins Godot](https://docs.godotengine.org/fr/4.x/tutorials/io/data_paths.html).
4. Détecte le clic sur l'écran de fin et relance la scène principale au niveau 1. Vérifie que les anciens boulets et minuteries ne persistent pas.
5. Ferme complètement le jeu, relance-le, puis perds une partie : le meilleur niveau précédent doit encore être affiché.

## 11. Vérifications finales

- [ ] Les quatre flèches changent immédiatement le côté protégé.
- [ ] Les canons ne tirent jamais exactement au même instant.
- [ ] Niveau 1 : un seul boulet à l'écran ; niveaux suivants : plusieurs possibles.
- [ ] Tous les boulets enlèvent 1 HP au robot ; leurs dégâts aux canons dépendent de leur couleur initiale.
- [ ] Les boulets renvoyés sont jaunes, rapides et reviennent au bon canon.
- [ ] Les canons détruits deviennent sombres et ne tirent plus.
- [ ] La transition dure une seconde et remet le robot à 5 HP.
- [ ] À partir du niveau 10, la difficulté cesse d'augmenter ; les niveaux continuent.
- [ ] À 0 HP, l'écran de mort s'affiche, le record est conservé et le clic redémarre la partie.
- [ ] Aucun son n'est nécessaire pour cette première version.

## Si tu es bloqué

Dis-moi **l'étape**, ce que tu as fait, ce que tu attendais et ce qui se passe. Si Godot affiche une erreur, copie le message rouge et le numéro de ligne. Nous pourrons corriger le problème avant de continuer.
