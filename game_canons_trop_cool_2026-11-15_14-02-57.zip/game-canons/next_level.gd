extends Button

func _on_pressed() -> void:
	Progression.niveau += 1
	get_tree().change_scene_to_file("res://main.tscn")
