extends Node

const CARTES: Array[Texture2D] = [
	preload("res://background.png"),
	preload("res://space.png"),
	preload("res://meteor.png")
]
const COULEURS: Array[Texture2D] = [
	preload("res://visuels_canons/boulet_blanc.svg"),
	preload("res://visuels_canons/boulet_vert.svg"),
	preload("res://visuels_canons/boulet_bleu.svg"),
	preload("res://visuels_canons/boulet_rouge.svg")
]

@onready var robot: Node2D = $Robot
@onready var canons: Array[Node] = [$CanonHaut, $CanonBas, $CanonGauche, $CanonDroite]
@onready var projectiles: Node = $Projectiles
@onready var fond: Sprite2D = $Sprite2D
var intervalles: Array[float] = []
var temps_restants: Array[float] = []
var fin_du_niveau := false
var attente_entre_tirs := 0.0


func _ready() -> void:
	var difficulte := mini(Progression.niveau, 10)
	fond.texture = CARTES[(Progression.niveau - 1) % CARTES.size()]
	var dimensions := get_viewport().get_visible_rect().size
	fond.position = dimensions / 2.0
	fond.scale = dimensions / fond.texture.get_size()
	var ancien_fond := get_node_or_null("Sprite2D2") as CanvasItem
	if ancien_fond:
		ancien_fond.visible = false
	for canon in canons:
		canon.configurer_vie(3 + roundi(17.0 * (difficulte - 1) / 9.0))
		canon.canon_detruit.connect(_verifier_victoire)
		var intervalle := randf_range(4.8, 6.8) - 0.15 * (difficulte - 1)
		intervalles.append(intervalle)
		temps_restants.append(randf_range(1.5, intervalle))
	var interface := CanvasLayer.new()
	var texte := Label.new()
	texte.text = "NIVEAU %d" % Progression.niveau
	texte.position = Vector2(16, 12)
	texte.add_theme_font_size_override("font_size", 28)
	interface.add_child(texte)
	add_child(interface)


func _process(delta: float) -> void:
	if fin_du_niveau:
		return
	attente_entre_tirs = maxf(0, attente_entre_tirs - delta)
	for i in range(canons.size()):
		if not canons[i].detruit:
			temps_restants[i] -= delta
	if attente_entre_tirs > 0.0:
		return
	if Progression.niveau == 1 and projectiles.get_child_count() > 0:
		return
	var disponibles: Array[int] = []
	for i in range(canons.size()):
		if not canons[i].detruit and temps_restants[i] <= 0.0:
			disponibles.append(i)
	if disponibles.is_empty():
		return
	var choix: int = disponibles.pick_random()
	var difficulte := mini(Progression.niveau, 10)
	var nombre_couleurs := 1 if difficulte == 1 else (2 if difficulte <= 3 else (3 if difficulte <= 6 else 4))
	var couleur := randi_range(0, nombre_couleurs - 1)
	var vitesse_base := 105.0 + 5.5 * (difficulte - 1)
	var multiplicateur_degats := 2 if Progression.niveau >= 7 else 1
	var boulet = canons[choix].tirer(robot.global_position, projectiles, robot)
	boulet.configurer(COULEURS[couleur], (couleur + 1) * multiplicateur_degats, vitesse_base * (1.0 + 0.2 * couleur) * randf_range(0.96, 1.04), vitesse_base * 1.6, multiplicateur_degats)
	temps_restants[choix] = intervalles[choix]
	attente_entre_tirs = 2.2 - 0.08 * (difficulte - 1)


func _verifier_victoire() -> void:
	for canon in canons:
		if not canon.detruit:
			return
	fin_du_niveau = true
	call_deferred("_victory")


func _victory() -> void:
	get_tree().change_scene_to_file("res://victory.tscn")
