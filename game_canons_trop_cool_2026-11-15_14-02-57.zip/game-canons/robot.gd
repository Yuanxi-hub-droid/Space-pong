extends Node2D

const DISTANCE := 42.0
const VIE_MAX := 5
var vie := VIE_MAX
var direction_bouclier := Vector2.UP

@onready var bouclier: Node2D = $Bouclier
@onready var barre_de_vie: ProgressBar = $BarreDeVie


func _ready() -> void:
	placer_bouclier(Vector2.UP)
	barre_de_vie.max_value = VIE_MAX
	barre_de_vie.value = vie


func _process(_delta: float) -> void:
	if Input.is_action_just_pressed("ui_up"):
		placer_bouclier(Vector2.UP)
	elif Input.is_action_just_pressed("ui_down"):
		placer_bouclier(Vector2.DOWN)
	elif Input.is_action_just_pressed("ui_left"):
		placer_bouclier(Vector2.LEFT)
	elif Input.is_action_just_pressed("ui_right"):
		placer_bouclier(Vector2.RIGHT)


func placer_bouclier(direction: Vector2) -> void:
	direction_bouclier = direction
	bouclier.position = direction * DISTANCE
	bouclier.rotation = PI / 2.0 if direction.x != 0.0 else 0.0


func bloque_boulet(direction_arrivee: Vector2) -> bool:
	return direction_bouclier == direction_arrivee


func recevoir_degats(nombre: int) -> void:
	if nombre <= 0:
		return
	vie = maxi(0, vie - nombre)
	barre_de_vie.value = vie
	if vie == 0:
		game_over()


func game_over():
	
	get_tree().change_scene_to_file("res://game_over.tscn")
   
