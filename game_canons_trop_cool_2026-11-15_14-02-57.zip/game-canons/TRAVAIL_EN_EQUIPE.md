# Travailler à deux sur Game Canons

Ce dossier est la copie du jeu à partager : il contient `project.godot`, le robot, les scènes des canons et des boulets, et les images. Ouvrez cette copie dans Godot 4.7.

## Répartition proposée

- **Joueur 1 — robot et interface** : `robot.tscn`, `robot.gd` et les futures scènes d'interface. Travail à faire : vie du robot, bouclier, interface et écran de fin.
- **Joueur 2 — canons et boulets** : `canons/`, `boulets/` et, si nécessaire, `visuels_canons/`. Travail à faire : tirs, déplacement, collisions et dégâts des canons.
- **Intégration commune** : `main.tscn`, `project.godot` et les règles dans `specifications-jeu.md`. Prévenez-vous avant de modifier ces fichiers et intégrez les changements l'un après l'autre.

`canons/canon.tscn` est instanciée quatre fois dans `main.tscn` ; modifier sa scène change les quatre canons. Les canons tirent chacun leur tour un boulet blanc vers le robot. Les collisions et les dégâts restent à créer.

Gardez les scènes autonomes : un élément ne doit pas dépendre d'un chemin vers son parent. Pour connecter le robot, les tirs et les règles, convenez ensemble des signaux et des responsabilités au moment de créer ces comportements.

## Partager avec GitHub Desktop

1. Ajoutez ce dossier comme dépôt local et faites un premier commit en vérifiant que **tous les fichiers**, y compris `main.tscn`, les scènes, les SVG et les fichiers `.import`, sont cochés. Publiez ensuite le dépôt sur GitHub et invitez votre coéquipier.
2. Votre coéquipier clone le dépôt dans son propre dossier, puis importe son fichier `project.godot` dans Godot. Ne travaillez pas simultanément dans un dossier partagé.
3. Avant de commencer, récupérez les dernières modifications avec **Fetch origin**, puis **Pull origin** si proposé. Créez chacun une branche depuis `main` : par exemple `robot-interface` et `canons-boulets`.
4. Faites des commits réguliers sur votre branche, puis cliquez sur **Push origin**. Ouvrez une pull request sur GitHub pour réunir les changements dans `main` ; vérifiez ensemble les conflits éventuels avant la fusion.
5. Après une fusion, revenez sur `main`, récupérez les nouveautés avec **Pull origin**, puis créez une nouvelle branche pour la tâche suivante.

Le dossier `.godot/` est un cache généré par Godot et n'est pas à partager. Les fichiers source, les fichiers `.uid` et les fichiers `.import` sont à partager pour garder des références cohérentes.
