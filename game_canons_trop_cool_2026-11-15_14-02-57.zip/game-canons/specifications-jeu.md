# Jeu de défense du robot — spécifications

## Concept

Jeu 2D en vue de dessus réalisé avec Godot 4.7. Un robot immobile au centre d'une arène se protège des tirs de quatre canons en renvoyant leurs boulets. Le but est d'atteindre le niveau le plus élevé possible.

## Commandes et défense

- Les quatre flèches placent instantanément le bouclier sur le côté correspondant du robot.
- Le bouclier couvre entièrement le côté sélectionné et bloque les boulets qui arrivent de cette direction.
- Les canons tirent vers le robot avec un très léger angle. Les tirs restent bloquables par le bouclier du côté correspondant.
- Un boulet bloqué devient jaune et revient vers son canon d'origine à la vitesse d'un boulet rouge du niveau. Il conserve les dégâts associés à sa couleur d'origine.

## Vie et boulets

Le robot commence avec 5 HP, représentés par une barre de vie. Chaque boulet qui le touche lui retire 1 HP, quelle que soit sa couleur. Chaque canon a une barre de vie et reçoit les dégâts suivants lorsqu'un boulet renvoyé l'atteint :

| Couleur initiale | Vitesse relative dans le niveau | Dégâts au canon |
| --- | --- | ---: |
| Blanc | Normale | 1 |
| Vert | Un peu plus rapide | 2 |
| Bleu | Encore plus rapide | 3 |
| Rouge | Maximum | 4 |

Un canon à 0 HP cesse de tirer, reste visible et devient noir sombre. Tous les canons ont le même maximum de HP dans un niveau.

## Tirs et progression

- Deux canons ne tirent jamais exactement au même moment.
- Au niveau 1, un seul boulet peut être présent à l'écran à la fois ; ensuite, plusieurs sont possibles.
- Chaque canon reçoit au hasard une fréquence de tir au début du niveau, dans une plage adaptée à la difficulté. Les fréquences peuvent différer d'un canon à l'autre.
- La vitesse peut varier d'un boulet à l'autre, même pour un seul canon. Les couleurs indiquent la vitesse relative au niveau.
- Quand les quatre canons sont détruits, une transition « NIVEAU X » s'affiche pendant une seconde. Le robot récupère ses 5 HP et les canons sont restaurés avant la reprise des tirs.
- Les niveaux sont infinis. Les HP des canons, les plages de fréquence et les vitesses progressent jusqu'au niveau 10, puis restent constants.

| Niveau | HP par canon | Couleurs possibles |
| --- | ---: | --- |
| 1 | 3 | Blanc |
| 2–3 | 4–5 | Blanc, vert |
| 4–6 | 6–8 | Blanc, vert, bleu |
| 7–9 | 9–11 | Blanc, vert, bleu, rouge |
| 10 et suivants | 12 | Blanc, vert, bleu, rouge |

## Fin de partie et record

À 0 HP, la partie s'arrête. L'écran affiche « YOU ARE DEAD », « Record: … » avec le meilleur niveau atteint, et « Click to restart ». Un clic relance une partie au niveau 1. Le record est conservé entre les parties. Il n'y a pas de menu d'accueil ni de score par seconde.

## Présentation

- Fond uni sombre, terrain simple et éléments contrastés.
- Robot et canons en pixel art simple.
- Niveau actuel et barre de vie du robot affichés à l'écran ; barre de vie pour chaque canon.

## Paramètres à régler par essais

Les vitesses, intervalles de tir, probabilités des couleurs et dimensions exactes restent à définir et à équilibrer par des essais. Il faudra notamment vérifier que les tirs restent lisibles et que la transition entre les niveaux est agréable.
