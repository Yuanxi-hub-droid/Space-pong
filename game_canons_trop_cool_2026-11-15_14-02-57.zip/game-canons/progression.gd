extends Node

var niveau := 1