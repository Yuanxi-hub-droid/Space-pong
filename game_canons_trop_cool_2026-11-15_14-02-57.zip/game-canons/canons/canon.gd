
extends Sprite2D
signal canon_detruit
@export var vie_max := 5
var vie := 5
var detruit := false

const BOULET = preload("res://boulets/boulet.tscn")
const DISTANCE_SORTIE := 50.0


func tirer(cible: Vector2, conteneur: Node, robot: Node2D) -> Node2D:
	var direction := global_position.direction_to(cible)
	var boulet := BOULET.instantiate() as Node2D
	conteneur.add_child(boulet)
	boulet.global_position = global_position + direction * DISTANCE_SORTIE
	boulet.initialiser(cible, robot, self)
	return boulet
@onready var barre_de_vie: ProgressBar = get_node_or_null("BarreDeVie")

func _ready() -> void:
	configurer_vie(vie_max)


func configurer_vie(nouvelle_vie_max: int) -> void:
	vie_max = nouvelle_vie_max
	vie = vie_max
	if barre_de_vie != null:
		barre_de_vie.max_value = vie_max
		barre_de_vie.value = vie


func recevoir_degats(nombre: int) -> void:
	if nombre <= 0 or detruit:
		return

	vie = maxi(0, vie - nombre)

	if barre_de_vie != null:
		barre_de_vie.value = vie
	if vie == 0:
		detruit = true
		texture = load("res://visuels_canons/canon_casse.svg")
		canon_detruit.emit()
