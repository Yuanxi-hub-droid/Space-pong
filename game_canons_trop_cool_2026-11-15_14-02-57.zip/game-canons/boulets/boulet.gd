extends Sprite2D

@export var vitesse := 200.0
@export var degats := 1
var degats_robot := 1

const DISTANCE_BOUCLIER := 58.0
const IMAGE_JAUNE = preload("res://visuels_canons/boulet_jaune.svg")

var cible := Vector2.ZERO
var en_mouvement := false
var renvoye := false

var robot: Node2D
var canon_origine: Node2D
var direction_arrivee := Vector2.ZERO
var vitesse_retour := 240.0


func configurer(image: Texture2D, degats_canon: int, vitesse_tir: float, vitesse_renvoi: float, degats_sur_robot: int = 1) -> void:
	texture = image
	degats = degats_canon
	degats_robot = degats_sur_robot
	vitesse = vitesse_tir
	vitesse_retour = vitesse_renvoi


func initialiser(
	nouvelle_cible: Vector2,
	cible_robot: Node2D,
	canon: Node2D
) -> void:
	cible = nouvelle_cible
	robot = cible_robot
	canon_origine = canon

	var origine := global_position - cible

	if absf(origine.x) > absf(origine.y):
		direction_arrivee = Vector2(signf(origine.x), 0)
	else:
		direction_arrivee = Vector2(0, signf(origine.y))

	en_mouvement = true


func _physics_process(delta: float) -> void:
	if not en_mouvement:
		return

	var deplacement := vitesse * delta
	var distance := global_position.distance_to(cible)

	# Vérifie le bouclier seulement à l'aller.
	if not renvoye:
		if distance > DISTANCE_BOUCLIER and distance - deplacement <= DISTANCE_BOUCLIER:
			if is_instance_valid(robot) and robot.bloque_boulet(direction_arrivee):
				rebondir()
				return

	if distance <= deplacement:
		if renvoye and is_instance_valid(canon_origine):
			canon_origine.recevoir_degats(degats)
		elif not renvoye and is_instance_valid(robot):
			robot.recevoir_degats(degats_robot)

		queue_free()
	else:
		global_position = global_position.move_toward(cible, deplacement)


func rebondir() -> void:
	if not is_instance_valid(canon_origine):
		queue_free()
		return

	renvoye = true
	vitesse = vitesse_retour
	cible = canon_origine.global_position
	texture = IMAGE_JAUNE
